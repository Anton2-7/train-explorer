import { observer } from 'mobx-react-lite';
import React from 'react';
import { Navigate } from 'react-router-dom';
import authStore from 'store/authStore';

interface PrivateRouteProps {
  element: React.ReactElement;
}

const PrivateElement: React.FC<PrivateRouteProps> = ({ element }) => {
  const { token } = authStore;

  if (token) {
    return element;
  }

  return token === null ? null : <Navigate to="/signin" replace />;
};

export default observer(PrivateElement);
