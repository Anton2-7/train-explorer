import MainLayout from 'layouts/MainLayout/MainLayout';
import CreateStationPage from 'pages/CreateStationPage/CreateStationPage';
import HomePage from 'pages/HomePage/HomePage';
import LoginPage from 'pages/LoginPage/LoginPage';
import SignupPage from 'pages/SignupPage/SignupPage';
import PrivateElement from './PrivateElement';

export default [
  {
    path: '/',
    element: <MainLayout />,
    children: [
      {
        path: '/',
        element: <PrivateElement element={<HomePage />} />
      },
      {
        path: '/create-station',
        element: <PrivateElement element={<CreateStationPage />} />
      }
    ]
  },
  {
    path: '/signin',
    element: <LoginPage />
  },
  {
    path: '/signup',
    element: <SignupPage />
  }
];
