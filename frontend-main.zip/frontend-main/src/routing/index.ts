import { useRoutes } from 'react-router-dom';
import config from './config';

const Routes = () => useRoutes(config);

export default Routes;
