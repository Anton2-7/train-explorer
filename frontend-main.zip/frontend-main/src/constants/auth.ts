export const AUTH_TOKEN_KEY = 'AUTH_TOKEN';
