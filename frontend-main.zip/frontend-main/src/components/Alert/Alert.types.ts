export interface AlertProps {
  isOpen: boolean;
  header: string;
  body: string;
  onClose: () => void;
}
