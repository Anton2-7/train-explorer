import { LeafletMouseEventHandlerFn } from 'leaflet';
import { Marker } from 'types/routes';

export interface MapProps {
  position?: Marker;
  markers?: Array<Marker>;
  onClick?: LeafletMouseEventHandlerFn;
}
