import { divIcon } from 'leaflet';
import styles from './MapPin.module.css';

const MapPin = divIcon({
  html: `<svg viewBox="-3 2.2 23.5 27.8"><g xmlns="http://www.w3.org/2000/svg" viewBox="-3 2.2 23.5 27.8">
  <path d="M15.5,23.9C14.9,24.4,8.7,30,8.7,30s-5.7-5.2-7.4-7C-1,20.6-3,17.6-3,14C-3,7.5,2.3,2.2,8.7,2.2c6.5,0,11.7,5.3,11.7,11.8C20.5,17.9,18.1,21.3,15.5,23.9z"/>
  <path fill="#fff" d="M8.8,8.2c3.1,0,5.7,2.6,5.7,5.7c0,3.1-2.6,5.7-5.7,5.7c-3.1,0-5.7-2.6-5.7-5.7C3.1,10.8,5.6,8.2,8.8,8.2z"/>
</g></svg>`,
  className: styles.root,
  iconSize: [24, 40],
  iconAnchor: [12, 40]
});

export default MapPin;
