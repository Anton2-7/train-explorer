import { latLngBounds } from 'leaflet';
import React, { useEffect } from 'react';
import { useMapEvents } from 'react-leaflet';
import { MapEventsProps } from './MapEvents.types';

const MapEvents: React.FC<MapEventsProps> = ({ center, markers, onClick }) => {
  const map = useMapEvents({
    click: onClick
  });

  useEffect(() => {
    map.flyTo(center);
  }, [center, map]);

  useEffect(() => {
    if (markers?.length) {
      const bounds = latLngBounds(markers);
      map.fitBounds(bounds);
    }
  }, [markers, map]);

  return null;
};

export default MapEvents;
