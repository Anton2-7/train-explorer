import { LeafletMouseEventHandlerFn } from 'leaflet';
import { Marker } from 'types/routes';

export interface MapEventsProps {
  center: Marker;
  markers?: Array<Marker>;
  onClick?: LeafletMouseEventHandlerFn;
}
