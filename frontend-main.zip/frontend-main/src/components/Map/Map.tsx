import { Marker, MapContainer, TileLayer, Polygon } from 'react-leaflet';
import React from 'react';
import styles from './Map.module.css';
import { MapProps } from './Map.types';
import MapEvents from './MapEvents/MapEvents';
import { DEFAULT_MARKER_POSITION } from './Map.constants';
import MapPin from './MapPin/MapPin';

const Map: React.FC<MapProps> = (props) => {
  const { position: defaultPosition = DEFAULT_MARKER_POSITION, markers = [], onClick } = props;

  return (
    <MapContainer className={styles.root} center={defaultPosition} zoom={8}>
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      <MapEvents center={defaultPosition} onClick={onClick} />
      {markers.map((position) => {
        return <Marker key={position.lat} position={position} icon={MapPin} />;
      })}
      {markers.map((marker, index) => {
        const nextMarker = markers[index + 1];

        if (!nextMarker) return null;

        return (
          <Polygon
            key={marker.lat}
            pathOptions={{ color: '#4f4f4f' }}
            positions={[marker, nextMarker].map(({ lat, lng }) => [lat, lng])}
          />
        );
      })}
    </MapContainer>
  );
};

export default Map;
