import { AlertContext } from 'providers/AlertProvider';
import { useContext } from 'react';

interface OpenAlertProps {
  header: string;
  body: string;
}

const useAlert = () => {
  const { setHeader, setBody, onOpen } = useContext(AlertContext);
  return {
    open: ({ header, body }: OpenAlertProps) => {
      setHeader(header);
      setBody(body);
      onOpen();
    }
  };
};

export default useAlert;
