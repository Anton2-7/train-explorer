import { useDisclosure } from '@chakra-ui/react';
import Alert from 'components/Alert/Alert';
import React, { createContext, useState } from 'react';

interface Context {
  header: string;
  body: string;
  isOpen: boolean;
  onOpen: () => void;
  onClose: () => void;
  setHeader: React.Dispatch<React.SetStateAction<string>>;
  setBody: React.Dispatch<React.SetStateAction<string>>;
}

export const AlertContext = createContext<Context>({
  header: '',
  body: '',
  isOpen: false,
  onOpen: () => {},
  onClose: () => {},
  setHeader: () => {},
  setBody: () => {}
});

const AlertProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [header, setHeader] = useState('');
  const [body, setBody] = useState('');

  // eslint-disable-next-line react/jsx-no-constructed-context-values
  const value = {
    header,
    body,
    onOpen,
    isOpen,
    onClose,
    setHeader,
    setBody
  };

  return (
    <AlertContext.Provider value={value}>
      {children}
      <Alert />
    </AlertContext.Provider>
  );
};

export default AlertProvider;
