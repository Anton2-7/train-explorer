export interface AuthRequest {
  login: string;
  password: string;
}

export interface SigninResponse {
  token: string;
}

export interface SignupResponse {
  id: number;
}
