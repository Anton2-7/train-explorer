import { AxiosError } from 'axios';

export enum RequestStatuses {
  PENDING = 'PENDING',
  FULFILLED = 'FULFILLED',
  REJECTED = 'REJECTED',
  IDLE = 'IDLE'
}

export interface RequestState {
  status: RequestStatuses;
  error: null | AxiosError;
}
