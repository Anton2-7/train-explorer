export interface Marker {
  lat: number;
  lng: number;
}

export interface Station extends Marker {
  id: number;
  name: string;
  geoname: string;
}

export type UnsavedStation = Omit<Station, 'id' | 'geoname'>;

export interface CreateStationResponse {
  id: number;
}

export interface SelectStation {
  index: string;
  id: number;
}

export interface Cargo {
  total: number;
  filled: number;
}

export interface RouteRequest {
  date: Date;
  cargo: Cargo;
  stations: number[];
}

export interface Time {
  days: number;
  hours: number;
  minutes: number;
}
