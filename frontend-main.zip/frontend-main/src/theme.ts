import { baseTheme, extendTheme, withDefaultColorScheme } from '@chakra-ui/react';

const theme = extendTheme(
  {
    colors: {
      hack: {
        ...baseTheme.colors.red,
        500: '#99002a'
      }
    }
  },
  withDefaultColorScheme({
    colorScheme: 'hack'
  })
);

export default theme;
