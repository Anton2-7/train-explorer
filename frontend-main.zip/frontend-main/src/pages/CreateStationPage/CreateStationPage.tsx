import { Box, Stack } from '@chakra-ui/react';
import Map from 'components/Map/Map';
import { LeafletMouseEventHandlerFn } from 'leaflet';
import { observer } from 'mobx-react-lite';
import stationStore from 'store/stationStore';
import { DEFAULT_MAP_POSITION } from './CreateStationPage.constants';
import StationForm from './StationForm/StationForm';

const CreateStationPage = () => {
  const { setStationPosition, lat, lng } = stationStore;

  const markers = lat && lng ? [{ lat, lng }] : [];

  const handleMapClick: LeafletMouseEventHandlerFn = (event) => {
    setStationPosition(event.latlng);
  };

  return (
    <Stack direction={{ base: 'column', md: 'row' }}>
      <Box w="100%">
        <StationForm />
      </Box>
      <Box w="100%">
        <Map position={DEFAULT_MAP_POSITION} markers={markers} onClick={handleMapClick} />
      </Box>
    </Stack>
  );
};

export default observer(CreateStationPage);
