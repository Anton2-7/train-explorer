import {
  Box,
  Button,
  Container,
  FormControl,
  FormLabel,
  Heading,
  Input,
  Stack,
  useToast
} from '@chakra-ui/react';
import { observer } from 'mobx-react-lite';
import React from 'react';
import { useNavigate } from 'react-router-dom';
import stationStore from 'store/stationStore';

const StationForm = () => {
  const { name, setName, createStation } = stationStore;
  const toast = useToast();
  const navigate = useNavigate();

  const handleNameChange: React.ChangeEventHandler<HTMLInputElement> = (event) =>
    setName(event.target.value);

  const handleSubmit: React.FormEventHandler<HTMLFormElement> = (event) => {
    event.preventDefault();
    createStation()
      .then(() => {
        toast({
          title: 'Станция успешно добавлена',
          status: 'success',
          position: 'top',
          duration: 2000
        });
        navigate('/');
      })
      .catch((error) => {
        toast({
          title: error.message,
          status: 'error',
          position: 'top',
          duration: 2000
        });
      });
  };

  return (
    <Container p="10">
      <form onSubmit={handleSubmit}>
        <Heading size="md" mb="10">
          Создание станции
        </Heading>
        <Stack spacing="4">
          <Box>
            <FormControl id="text">
              <FormLabel>Название станции</FormLabel>
              <Input value={name} onChange={handleNameChange} />
            </FormControl>
          </Box>
          <Stack spacing={10} pt={2}>
            <Button loadingText="Submitting" size="lg" color="white" type="submit">
              Cоздать
            </Button>
          </Stack>
        </Stack>
      </form>
    </Container>
  );
};

export default observer(StationForm);
