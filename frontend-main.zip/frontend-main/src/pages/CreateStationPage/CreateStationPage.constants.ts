export const DEFAULT_MAP_POSITION = {
  lat: 55.7558,
  lng: 37.6173
};
