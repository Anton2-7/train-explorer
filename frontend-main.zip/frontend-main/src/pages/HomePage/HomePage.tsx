import { Box, Stack, useToast } from '@chakra-ui/react';
import Map from 'components/Map/Map';
import RouteForm from 'pages/HomePage/RouteForm/RouteForm';
import { observer } from 'mobx-react-lite';
import { useEffect } from 'react';
import routeStore from 'store/routeStore';

const HomePage = () => {
  const { stations, selectedStations, listStations } = routeStore;
  const toast = useToast();

  const currentStations = selectedStations
    .map((id) => {
      return stations.find((station) => station.id === id)!;
    })
    .filter((item) => item);

  useEffect(() => {
    listStations().catch((error) => {
      toast({
        title: error.message,
        status: 'error',
        position: 'top',
        duration: 2000
      });
    });
  }, [listStations, toast]);

  return (
    <Stack direction={{ base: 'column', md: 'row' }}>
      <Box w="100%">
        <RouteForm />
      </Box>
      <Box w="100%">
        <Map position={currentStations[0]} markers={currentStations} />
      </Box>
    </Stack>
  );
};

export default observer(HomePage);
