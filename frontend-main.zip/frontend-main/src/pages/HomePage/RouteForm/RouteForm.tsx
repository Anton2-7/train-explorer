import {
  Box,
  Button,
  Container,
  Divider,
  FormControl,
  FormLabel,
  Heading,
  Input,
  Select,
  Stack,
  useToast
} from '@chakra-ui/react';
import { observer } from 'mobx-react-lite';
import React from 'react';
import routeStore from 'store/routeStore';

const RouteForm = () => {
  const {
    selectStation,
    stations,
    selectedStations,
    calculateTime,
    cargo,
    setCargoTotal,
    setCargoFilled,
    setDepartureDate,
    loading,
    setLoading
  } = routeStore;
  const toast = useToast();

  const handleSelect: React.ChangeEventHandler<HTMLSelectElement> = (event) => {
    const { name, value } = event.target;
    selectStation({
      index: name,
      id: Number(value)
    });
  };

  const handleCargoFilledChange: React.ChangeEventHandler<HTMLInputElement> = (event) => {
    setCargoFilled(Number(event.target.value));
  };

  const handleCargoTotalChange: React.ChangeEventHandler<HTMLInputElement> = (event) => {
    setCargoTotal(Number(event.target.value));
  };

  const handleDepartureDateChange: React.ChangeEventHandler<HTMLInputElement> = (event) => {
    setDepartureDate(new Date(event.target.value));
  };

  const handleSubmit: React.FormEventHandler<HTMLFormElement> = (event) => {
    event.preventDefault();
    setLoading(true);
    calculateTime()
      .then((data) => {
        toast({
          title: 'Результаты анализа',
          description: `Время в пути: ${data.days} часов ${data.hours} часов ${data.minutes} минут`,
          status: 'success',
          position: 'top'
        });
      })
      .catch((error) => {
        toast({
          title: error.message,
          status: 'error',
          position: 'top',
          duration: 2000
        });
      })
      .finally(() => {
        setLoading(false);
      });
  };

  return (
    <Container p="10">
      <form onSubmit={handleSubmit}>
        <Heading size="md" mb="10">
          Анализ маршрута
        </Heading>
        <Stack spacing="4">
          {Array.from({ length: 2 }).map((_, id) => {
            const index: string = String(id);
            return (
              <Box key={index}>
                <FormControl id="station">
                  <FormLabel>Пункт</FormLabel>
                  <Select onChange={handleSelect} name={index} placeholder="Выберите пункт">
                    {stations
                      .filter((option) => {
                        return (
                          selectedStations.indexOf(option.id) === id ||
                          !selectedStations.includes(option.id)
                        );
                      })
                      .map((station) => {
                        const { geoname, name } = station;
                        return (
                          <option
                            key={station.id}
                            value={station.id}
                            label={`${name} (${geoname})`}
                          />
                        );
                      })}
                  </Select>
                </FormControl>
              </Box>
            );
          })}
          <Divider />
          <Stack direction={{ base: 'column', lg: 'row' }} spacing={2}>
            <Box w="100%">
              <FormControl id="filled">
                <FormLabel>Загружено вагонов</FormLabel>
                <Input value={cargo.filled} onChange={handleCargoFilledChange} type="number" />
              </FormControl>
            </Box>
            <Box w="100%">
              <FormControl id="total">
                <FormLabel>Всего вагонов</FormLabel>
                <Input value={cargo.total} onChange={handleCargoTotalChange} type="number" />
              </FormControl>
            </Box>
          </Stack>
          <Divider />
          <Box>
            <FormControl id="total">
              <FormLabel>Время отбытия</FormLabel>
              <Input onChange={handleDepartureDateChange} type="datetime-local" />
            </FormControl>
          </Box>
          <Stack spacing={10} pt={2}>
            <Button
              loadingText="Загрузка..."
              size="lg"
              color="white"
              type="submit"
              isLoading={loading}
            >
              Провести анализ
            </Button>
          </Stack>
        </Stack>
      </form>
    </Container>
  );
};

export default observer(RouteForm);
