import React, { useState } from 'react';
import {
  Button,
  Checkbox,
  Flex,
  FormControl,
  FormLabel,
  Heading,
  Input,
  Link,
  Stack,
  Image,
  useToast
} from '@chakra-ui/react';
import authStore from 'store/authStore';
import { observer } from 'mobx-react-lite';
import { useNavigate } from 'react-router-dom';
import Wagon from '../../assets/images/wagon.jpg';

const LoginPage = () => {
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const toast = useToast();

  const handleLoginChange = (event: React.ChangeEvent<HTMLInputElement>) =>
    setLogin(event.target.value);

  const handlePasswordChange = (event: React.ChangeEvent<HTMLInputElement>) =>
    setPassword(event.target.value);

  const handleSubmit: React.FormEventHandler<HTMLFormElement> = (event) => {
    event.preventDefault();
    authStore
      .signIn({
        login,
        password
      })
      .then(() => {
        navigate('/');
      })
      .catch((error) => {
        toast({
          title: error.message,
          status: 'error',
          position: 'top',
          duration: 2000
        });
      });
  };

  return (
    <form onSubmit={handleSubmit}>
      <Stack minH="100vh" direction={{ base: 'column', md: 'row' }}>
        <Flex p={8} flex={1} align="center" justify="center">
          <Stack spacing={4} w="full" maxW="md">
            <Heading fontSize="2xl">Вход</Heading>
            <FormControl id="email">
              <FormLabel>Введите ваш email-адрес</FormLabel>
              <Input value={login} onChange={handleLoginChange} />
            </FormControl>
            <FormControl id="password">
              <FormLabel>Введите пароль</FormLabel>
              <Input value={password} onChange={handlePasswordChange} type="password" />
            </FormControl>
            <Stack spacing={6}>
              <Stack
                direction={{ base: 'column', sm: 'row' }}
                align="start"
                justify="space-between"
              >
                <Checkbox>Запомнить меня</Checkbox>
                <Link href="/#">Забыли пароль?</Link>
              </Stack>
              <Button variant="solid" type="submit">
                Вход
              </Button>
            </Stack>
          </Stack>
        </Flex>
        <Flex flex={1}>
          <Image alt="Login Image" objectFit="cover" src={Wagon} />
        </Flex>
      </Stack>
    </form>
  );
};

export default observer(LoginPage);
