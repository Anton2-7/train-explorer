import api from 'api/index';
import { makeAutoObservable } from 'mobx';
import { UnsavedStation, Marker } from 'types/routes';

class StationStore {
  name: string = '';
  lng?: number;
  lat?: number;

  constructor() {
    makeAutoObservable(
      this,
      {},
      {
        autoBind: true
      }
    );
  }

  // eslint-disable-next-line class-methods-use-this
  async createStation() {
    if (!(this.lat && this.lng)) throw new Error('Выберите местоположение');
    const data: UnsavedStation = {
      name: this.name,
      lat: this.lat,
      lng: this.lng
    };
    await api.stations.create(data);
  }

  setName(name: string) {
    this.name = name;
  }

  setStationPosition(marker: Marker) {
    const { lat, lng } = marker;
    this.lat = lat;
    this.lng = lng;
  }
}

const stationStore = new StationStore();

export default stationStore;
