import api from 'api/index';
import { AUTH_TOKEN_KEY } from 'constants/auth';
import { makeAutoObservable, reaction } from 'mobx';
import { AuthRequest } from 'types/auth';

class AuthStore {
  id?: number;
  token: string | null = null;
  isAuth = !!this.token;

  constructor() {
    makeAutoObservable(this);
    const token = localStorage.getItem(AUTH_TOKEN_KEY);
    this.token = token ?? '';
  }

  async signUp(data: AuthRequest) {
    const response = await api.auth.signUp(data);
    const { id } = response.data;
    this.id = id;
  }

  async signIn(data: AuthRequest) {
    try {
      const response = await api.auth.signIn(data);
      const { token } = response.data;
      this.token = token;
    } catch (error) {
      this.token = '';
      throw error;
    }
  }
}

const authStore = new AuthStore();

reaction(
  () => authStore.token,
  (token) => {
    if (token) {
      localStorage.setItem(AUTH_TOKEN_KEY, token);
    } else {
      localStorage.removeItem(AUTH_TOKEN_KEY);
    }
  }
);

export default authStore;
