import api from 'api/index';
import { makeAutoObservable } from 'mobx';
import { Station, SelectStation, Cargo } from 'types/routes';

class RouteStore {
  stations: Station[] = [];
  selectedStations: number[] = [];
  cargo: Cargo = {
    total: 0,
    filled: 0
  };
  departureDate: Date = new Date();
  loading = false;

  constructor() {
    makeAutoObservable(
      this,
      {},
      {
        autoBind: true
      }
    );
    this.listStations();
  }

  // eslint-disable-next-line class-methods-use-this
  async listStations() {
    const response = await api.stations.list();
    this.stations = response.data;
  }

  async calculateTime() {
    const response = await api.routes.calculateTime({
      date: new Date(),
      cargo: this.cargo,
      stations: this.selectedStations
    });
    return response.data;
  }

  setLoading(value: boolean) {
    this.loading = value;
  }

  selectStation(station: SelectStation) {
    const { index, id } = station;
    this.selectedStations[Number(index)] = id;
  }

  setCargoTotal(value: number) {
    this.cargo.total = value;
  }

  setCargoFilled(value: number) {
    this.cargo.filled = value;
  }

  setDepartureDate(value: Date) {
    this.departureDate = value;
  }
}

const routeStore = new RouteStore();

export default routeStore;
