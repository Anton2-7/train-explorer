import { RouteRequest, Time } from 'types/routes';
import client from './lib/client';

const routes = {
  calculateTime(data: RouteRequest) {
    return client.post<Time>('/api/v1/routes', data);
  }
};

export default routes;
