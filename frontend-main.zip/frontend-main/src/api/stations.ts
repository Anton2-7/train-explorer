import { CreateStationResponse, Station, UnsavedStation } from 'types/routes';
import client from './lib/client';

const stations = {
  list() {
    return client.get<Station[]>('/api/v1/stations');
  },
  create(data: UnsavedStation) {
    return client.post<CreateStationResponse>('/api/v1/stations', data);
  }
};

export default stations;
