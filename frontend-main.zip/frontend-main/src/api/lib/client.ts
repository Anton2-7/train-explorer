import axios from 'axios';
import { AUTH_TOKEN_KEY } from 'constants/auth';

const client = axios.create({
  baseURL: import.meta.env.VITE_API_URL
});

client.interceptors.request.use(async (req) => {
  const token = localStorage.getItem(AUTH_TOKEN_KEY);
  if (token && req.headers) {
    req.headers.authorization = `Bearer ${token}`;
  }
  return req;
});

export default client;
