import auth from './auth';
import routes from './routes';
import stations from './stations';

const api = {
  auth,
  routes,
  stations
};

export default api;
