import { AuthRequest, SigninResponse, SignupResponse } from 'types/auth';
import client from './lib/client';

const auth = {
  signUp(data: AuthRequest) {
    return client.post<SignupResponse>('/api/v1/auth/sign-up', data);
  },
  signIn(data: AuthRequest) {
    return client.post<SigninResponse>('/api/v1/auth/sign-in', data);
  }
};

export default auth;
