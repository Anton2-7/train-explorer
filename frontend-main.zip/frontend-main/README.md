# Анализ времени движения грузовых поездов

## Stack

- Typescript
- React
- Mobx
- Chakra UI
- Axios
- Vite


## Installation

To run the server, you will need to have Node JS installed.
After that, run this command:

```
$ yarn
```

## Development

```
$ yarn dev
```

## Build

```
$ yarn build
```

## Start

```
$ yarn preview
```
